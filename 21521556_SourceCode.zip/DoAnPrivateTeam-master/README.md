# PrivateJavaTeam
# Lập trình Java - IS216.N23 - GVHD: thầy Tạ Việt Phương
Thành viên nhóm Private  
|  MSSV  |          HOTEN           |          GMAIL         |
|:------:|:------------------------:|:----------------------:|
|21522812|Nguyễn Triệu Vy - leader  |21522812@gm.uit.edu.vn  |
|21520086|Huỳnh Lê Phong            |21520086@gm.uit.edu.vn  |
|21520798|Đặng Lưu Hà	              |21520798@gm.uit.edu.vn  |
|21521556|Nguyễn Quốc Trạng         |21521556@gm.uit.edu.vn  |

##
Link video demo: https://drive.google.com/file/d/1JreWZj_iWOflVDglPK1dEUlTImvJz-LI/view?usp=drive_link
##
link source databases ORACLE: https://drive.google.com/file/d/1aa-wq8gKtI3nQV-F_RwixdjgFNoiheuk/view?usp=sharing
##
link library java: https://drive.google.com/drive/folders/189lURFDrOJb9nHrVHfyCwhvDscPbZrZb
##
website giới thiệu nhóm: https://private.renderforestsites.com/hopdong/?fbclid=IwAR1nAYrZDQ9rFT3gM5DjFdFYafE1pwWnwQB-5ZCil8z3jkS6g2xvzqQkbE0
##
Tổng hợp: https://drive.google.com/drive/folders/15yWqIxGENSgDOINHvwDaBi2gP6f8HjV- 


