/* DATABASES QUAN LY HIEU SACH */
-- DELETE TABLE --
DROP TABLE CTPN;
DROP TABLE CTHD;
DROP TABLE PHIEUNHAP;
DROP TABLE HOADON;
DROP TABLE KHACHHANG;
DROP TABLE TAIKHOAN;
DROP TABLE NHANVIEN;
DROP TABLE SACH;
DROP TABLE THELOAI;
DROP TABLE NHACUNGCAP;
--
/* DELETE SEQUENCE */
DROP SEQUENCE MANCC_SEQ1;
DROP SEQUENCE MATL_SEQ2;
DROP SEQUENCE MASACH_SEQ3;
DROP SEQUENCE MAKH_SEQ4;
DROP SEQUENCE MANV_SEQ5;
DROP SEQUENCE MATK_SEQ6;
DROP SEQUENCE MAHD_SEQ7;
DROP SEQUENCE MAPN_SEQ8;


--TABLE NHACUNGCAP--
CREATE TABLE NHACUNGCAP
(
    MaNCC number not null,
    TenNCC varchar2(100) not null,
    DiaChi varchar2(100) not null,
    SDT varchar2(12),
    CONSTRAINT PK_NCC PRIMARY KEY (MaNCC)
);
CREATE SEQUENCE MANCC_SEQ1 START WITH 1;

-- TABLE THELOAI
CREATE TABLE THELOAI
(
    MaTL number not null,
    TheLoai varchar2(30) not null,
    GhiChu varchar2(1000),
    CONSTRAINT PK_THELOAI PRIMARY KEY (MaTL) 
);
CREATE SEQUENCE MATL_SEQ2 START WITH 1;

-- TABLE SACH --
CREATE TABLE SACH
(
    MaSach number not null,
    TenSach varchar2(80) not null,
    MaTL number CONSTRAINT FK_TL_SACH REFERENCES THELOAI(MaTL) not null,
    TenTG varchar2(150),
    NamXB date,
    NXB varchar(60),
    HinhThucBia varchar2(15),
    TomTat varchar2(1000),
    SL number,
    Gia number,
    MaNCC number CONSTRAINT FK_SACH_NCC REFERENCES NHACUNGCAP(MaNCC) not null,
    NgonNgu varchar2(35),
    HinhAnh varchar2(500) default 'user.jpg',
    CONSTRAINT PK_SACH PRIMARY KEY (MaSach)
);
CREATE SEQUENCE MASACH_SEQ3 START WITH 1;

-- TABLE KHACHHANG --
CREATE TABLE KHACHHANG
(
    MaKH number not null,
    Ho varchar2(20) not null,
    Ten varchar2(20) not null,
    NgaySinh date not null,
    GioiTinh varchar2(10) not null,
    SoDT varchar2(10),
    LoaiKH varchar2(20) default 'Thường',
    DiemTichLuy Number default 0,
    CONSTRAINT PK_KH PRIMARY KEY (MaKH)
);
CREATE SEQUENCE MAKH_SEQ4 START WITH 1;

-- TABLE NHANVIEN --
CREATE TABLE NHANVIEN
(
    MaNV number not null,
    Ho varchar2(20) not null,
    Ten varchar2(20) not null,
    GioiTinh varchar2(15),
    DiaChi varchar2(100) not null,
    CMND varchar2(15) not null,
    NgaySinh date not null,
    NgayBD date not null,
    SoDT varchar2(10) not null,
    Luong number not null,
    HinhAnh varchar2(500),
    CONSTRAINT PK_NV PRIMARY KEY (MaNV)
);
CREATE SEQUENCE MANV_SEQ5 START WITH 1;

--TABLE TAIKHOAN--
CREATE TABLE TAIKHOAN
(
    MaTK number not null,
    TenTK varchar2(30),
    MatKhau varchar2(30),
    LoaiTK varchar2(30),
    MaNV number CONSTRAINT FK_TK_NV REFERENCES NHANVIEN(MaNV) not null,
    CONSTRAINT PK_TAIKHOAN PRIMARY KEY (MaTK)
);
CREATE SEQUENCE MATK_SEQ6 START WITH 1;

--TABLE HOADON--
CREATE TABLE HOADON
(
    MaHD number not null,
    NgayHD date not null,
    MaNV number CONSTRAINT FK_HD_NV REFERENCES NHANVIEN(MaNV) not null,
    MaKH number CONSTRAINT FK_HD_KH REFERENCES KHACHHANG(MaKH) null,
    ThanhTien number,
    CONSTRAINT PK_HOADON PRIMARY KEY (MaHD)
);
CREATE SEQUENCE MAHD_SEQ7 START WITH 1;

--TABLE PHIEUNHAP--
CREATE TABLE PHIEUNHAP
(
    MaPN number not null,
    NgayNhap date not null,
    TongTien number,
    MaNV number CONSTRAINT FK_PN_NV REFERENCES NHANVIEN(MaNV) not null,
    CONSTRAINT PK_PHIEUNHAP PRIMARY KEY (MaPN)
);
CREATE SEQUENCE MAPN_SEQ8 START WITH 1;

--TABLE CTPN --
CREATE TABLE CTPN
(
    MaPN number CONSTRAINT FK_CTPN_PN REFERENCES PHIEUNHAP(MaPN) not null,
    MaSach number CONSTRAINT FK_CTPN_SACH REFERENCES SACH(MaSach) not null,
    SL number not null,
    Gia number not null,
    CONSTRAINT PK_CTPN PRIMARY KEY (MaSach, MaPN)
);

--TABLE CTHD--
CREATE TABLE CTHD
(
    MaHD number CONSTRAINT FK_CTHD_HD REFERENCES HOADON(MaHD) not null,
    MaSach number CONSTRAINT FK_CTHD_SACH REFERENCES SACH(MaSach) not null,
    SL number not null,
    CONSTRAINT PK_CTHD PRIMARY KEY (MaHD, MaSach)
);

--FORMAT DATE
ALTER SESSION SET NLS_DATE_FORMAT ='DD/MM/YYYY';
-- PROCEDURE
/
create or replace NONEDITIONABLE PROCEDURE sleep (in_time number)
AS
    v_now date;
BEGIN
    SELECT SYSDATE
    INTO v_now
    FROM DUAL;

    LOOP
    EXIT WHEN v_now + (in_time * (1/86400)) <= SYSDATE;
    END LOOP;
end;
/
create or replace procedure sp_ThemCTPN(
    v_MaPN_in IN CTPN.MaPN%type,
    v_MaSach_in IN CTPN.MaSach%type,
    v_SL_in IN CTPN.SL%type,
    v_Gia_in IN CTPN.GIA%type
)
as
    v_sl number;
    v_TongTien number;
begin
    select SL into v_sl
    from SACH
    where MaSach = v_MaSach_in;
    
    select TongTien into v_TongTien
    from PHIEUNHAP
    where MAPN = v_MaPN_in;
    
    insert into CTPN(MaPN, MaSach, SL, Gia) values(v_MaPN_in, v_MaSach_in, v_SL_in, v_Gia_in);
    
    update PHIEUNHAP
    set TongTien = v_TongTien + v_SL_in * v_Gia_in
    where MAPN = v_MaPN_in;

    update SACH
    set SL = v_sl + v_SL_in
    where MaSach = v_MaSach_in;
    commit;
end;
/
create or replace procedure sp_ThemCTHD(
    v_MaHD_in IN CTHD.MaHD%type,
    v_MaSach_in IN CTHD.MaSach%type,
    v_SL_in IN CTHD.SL%type
)
as
    v_MaKH KHACHHANG.MAKH%type;
    v_GiaSach SACH.GIA%type;
    v_valueCTHD number;
    v_DTL KHACHHANG.DIEMTICHLUY%type;
    v_sl number;
begin
    select SL into v_sl from SACH where MASACH = v_MaSach_in;
    insert into CTHD(MaHD, MaSach, SL) values(v_MaHD_in, v_MaSach_in, v_SL_in);
    
    update SACH
    set SL = v_sl - v_SL_in
    where MaSach = v_MaSach_in;
    
    select Gia into v_GiaSach
    from SACH
    where MaSach = v_MaSach_in;
    
    v_valueCTHD := v_SL_in * v_GiaSach;
    
    update HOADON
    set ThanhTien = ThanhTien + v_valueCTHD
    where MAHD = v_MAHD_in;
    
    select MAKH into v_MaKH
    from HOADON
    where MAHD = v_MaHD_in;
    
    if (v_MaKH is not null) then
        update KHACHHANG
        set DIEMTICHLUY = DIEMTICHLUY + v_valueCTHD
        where MAKH = v_MaKH;
        
        select DIEMTICHLUY into v_DTL
        from KHACHHANG
        where MAKH = v_MaKH;
        
        if (v_DTL >= 2000000) then
            update KHACHHANG
            set LOAIKH = 'VIP'
            where MAKH = v_MaKH;
        elsif (v_DTL >= 500000) then
            update KHACHHANG
            set LOAIKH = 'Thân Thiết'
            where MAKH = v_MaKH;
        elsif (v_DTL < 500000) then
            update KHACHHANG
            set LOAIKH = 'Thường'
            where MAKH = v_MaKH;
        end if;
    end if;
    --sleep(10);
    commit;
end;
/
create or replace procedure sp_XoaNHANVIEN(
    v_MaNV_in NHANVIEN.MANV%type
)
as
begin
    delete from CTHD where MaHD in (select MaHD from HOADON where MaNV = v_MaNV_in);
    delete from HOADON where MaNV = v_MaNV_in;
    delete from CTPN where MaPN in (select MaPN from PHIEUNHAP where MaNV = v_MaNV_in);
    delete from PHIEUNHAP where MaNV = v_MaNV_in;
    delete from TAIKHOAN where MANV = v_MaNV_in;
    delete from NHANVIEN where MaNV = v_MaNV_in;
    commit;
end;
/
create or replace procedure sp_XoaKHACHHANG(
    v_MaKH_in KHACHHANG.MAKH%type
)
as
begin
    delete from CTHD where MaHD in (select MaHD from HOADON where MaKH = v_MaKH_in);
    delete from HOADON where MaKH = v_MaKH_in;
	delete from KHACHHANG where MAKH = v_MaKH_in;
    commit;
end;
/
create or replace procedure sp_XoaHOADON(
    v_MaHD_in HOADON.MAHD%type
)
as
begin
    sleep(5);
    delete from CTHD where MaHD = v_MaHD_in;
    delete from HOADON where MaHD = v_MaHD_in;
    commit;
end;
/
create or replace procedure sp_XoaPhieuNhap(
    v_MaPN_in PHIEUNHAP.MAPN%type
)
as
begin
    delete from CTPN where MaPN = v_MaPN_in;
    delete from PHIEUNHAP where MaPN = v_MaPN_in;
    commit;
end;
/
-- Ràng buột toàn vẹn
--RB9: CHECK TAIKHOAN: Với mọi tài khoản, tên tài khoản là duy nhất
ALTER TABLE TaiKhoan
ADD CONSTRAINT TaiKhoan_Unique_TenTK
UNIQUE (TenTK);

ALTER TABLE TaiKhoan
ADD CONSTRAINT TaiKhoan_Unique_LoaiTK_MaNV
UNIQUE (LoaiTK, MaNV);
--
commit;

--RB10: CHECK NHANVIEN: Với mọi nhân viên, ngày bắt đầu làm (NgayBD) luôn lớn hơn ngày sinh (NgaySinh) của nhân viên đó.
ALTER TABLE NHANVIEN
ADD CONSTRAINT check_NgayBD_NgaySinh
CHECK (NgayBD > NgaySinh);

--RB11: CHECK SACH: Với mọi cuốn sách, kiểm tra Giá và Số lượng luôn lớn hơn hoặc bằng 0.
ALTER TABLE SACH
ADD CONSTRAINT check_Gia_SoLuong
CHECK (Gia >= 0 and SL >= 0);

--trigger
/
create or replace trigger TRG19_NGBD_NGHD_NHANVIEN_up
before update of NgayBD on NHANVIEN
for each row
declare
    cursor curNGHD is select NGAYHD from HOADON where MANV = :new.MANV;
    v_NGAYHD date;
begin
    open curNGHD;
    LOOP
        FETCH curNGHD into v_NGAYHD;
        EXIT WHEN curNGHD%NOTFOUND;
        if (v_NGAYHD < :new.NGAYBD) then
            raise_application_error(-20001, 'Ngay bat dau lam khong hop le');
        end if;
    END LOOP;
end;
/
create or replace trigger TRG19_NGBD_NGHD_HOADON_in_up
before insert or update of MaNV, NgayHD on HOADON
for each row
declare
    cursor curNGBD is select NGAYBD from NHANVIEN where MANV = :new.MANV;
    v_NGAYBD date;
begin
    open curNGBD;
    LOOP
        FETCH curNGBD into v_NGAYBD;
        EXIT WHEN curNGBD%NOTFOUND;
        if (:new.NGAYHD < v_NGAYBD) then
            raise_application_error(-20002, 'NgayHD khong hop le');
        end if;
    END LOOP;
end;
/
-- RB20:Ngày nhập hàng (NgayNhap) vào kho hàng của một nhân viên phải lớn hơn hoặc bằng ngày nhân viên đó vào làm (NgayBD).
create or replace trigger TRG20_NGBD_NGNHAP_NHANVIEN_up
before update of NgayBD on NHANVIEN
for each row
declare
    cursor curNGNHAP is select NGAYNHAP from PHIEUNHAP where MANV = :new.MANV;
    v_NGAYNHAP date;
begin
    open curNGNHAP;
    LOOP
        FETCH curNGNHAP into v_NGAYNHAP;
        EXIT WHEN curNGNHAP%NOTFOUND;
        if (v_NGAYNHAP < :new.NGAYBD) then
            raise_application_error(-20003, 'Ngay bat dau lam khong hop le');
        end if;
    END LOOP;
end;
/
create or replace trigger TRG20_NGBD_NGNHAP_PHIEUNHAP_in_up
before insert or update of MaNV, NgayNhap on PHIEUNHAP
for each row
declare
    cursor curNGBD is select NGAYBD from NHANVIEN where MANV = :new.MANV;
    v_NGAYBD date;
begin
    open curNGBD;
    LOOP
        FETCH curNGBD into v_NGAYBD;
        EXIT WHEN curNGBD%NOTFOUND;
        if (:new.NGAYNHAP < v_NGAYBD) then
            raise_application_error(-20004, 'NgayNhap khong hop le');
        end if;
    END LOOP;
end;
/
-- RB21: Ngày mua hàng (NgayHD) của một khách hàng phải lớn hơn hoặc bằng ngày sinh của khách hàng đó (NgaySinh).
create or replace trigger TRG21_NGSINHKH_NGHD_KHACHHANG_up
before update of NgaySinh on KHACHHANG
for each row
declare
    cursor curNGHD is select NGAYHD from HOADON where MAKH = :new.MAKH;
    v_NGAYHD date;
begin
    open curNGHD;
    LOOP
        FETCH curNGHD into v_NGAYHD;
        EXIT WHEN curNGHD%NOTFOUND;
        if (v_NGAYHD < :new.NGAYSINH) then
            raise_application_error(-20005, 'Ngay Sinh khong hop le');
        end if;
    END LOOP;
end;
/
create or replace trigger TRG21_NGSINHKH_NGHD_HOADON_in_up
before insert or update of NgayHD on HOADON
for each row
declare
    cursor curNGSINH is select NGAYSINH from KHACHHANG where MAKH = :new.MAKH;
    v_NGAYSINH date;
begin
    open curNGSINH;
    LOOP
        FETCH curNGSINH into v_NGAYSINH;
        EXIT WHEN curNGSINH%NOTFOUND;
        if (:new.NGAYHD < v_NGAYSINH) then
            raise_application_error(-20006, 'NgayHD khong hop le');
        end if;
    END LOOP;
end;
/
create or replace trigger TRG22_ThanhTien_HOADON_in
before insert on HOADON
for each row
begin
    if (:new.ThanhTien != 0) then
        raise_application_error(-20007, 'Khi them moi 1 HOADON, ThanhTien = 0 (hệ thống sẽ tự động tính lại khi hoàn tất insert CTHD thuoc HD nay)');
    end if;
end;
/
create or replace trigger TRG25_DiemTL_KHACHHANG_in
before insert on KHACHHANG
for each row
begin
    if (:new.DIEMTICHLUY != 0) then
        raise_application_error(-20008, 'Khi them moi 1 KHACHHANG, DIEMTICHLUY = 0 (hệ thống sẽ tự động tính lại khi hoàn tất insert CTHD thuoc HOADON cua KHACHHANG nay)');
    end if;
end;
/
create or replace trigger TRG23_GIANHAP_GIABAN_CTPN
before insert or update of MASACH, GIA on CTPN
for each row
declare
    cursor curGiaBanSach is select Gia from SACH where MASACH = :new.MASACH;
    v_GiaBan number;
begin
    open curGiaBanSach;
    LOOP
        FETCH curGiaBanSach into v_GiaBan;
        EXIT WHEN curGiaBanSach%NOTFOUND;
        if (:new.Gia > v_GiaBan) then
            raise_application_error(-20009, 'Gia Nhap khong phu hop');
        end if;
    END LOOP;
end;
/
create or replace trigger TRG_AUTO_checkGIA_ThanhTien_DIEMTL_LOAIKH_SACH_upGIA
after update of GIA on SACH
for each row
declare
    cursor curMaHD is select MaHD, SL from  CTHD where MaSach = :new.MaSach;
    cursor curCTNhapSach is select Gia from CTPN where MASACH = :new.MASACH;
    v_GiaNhap number;
    v_MaHD HOADON.MaHD%type;
    v_SL CTHD.SL%type;
    v_MAKH KHACHHANG.MAKH%type;
    v_DTL KHACHHANG.DIEMTICHLUY%type;
begin
    open curCTNhapSach;
    LOOP
        FETCH curCTNhapSach into v_GiaNhap;
        EXIT WHEN curCTNhapSach%NOTFOUND;
        if (:new.Gia < v_GiaNhap) then
            raise_application_error(-20010, 'Gia ban khong phu hop');
        end if;
    END LOOP;
    open curMaHD;
    LOOP
        FETCH curMaHD into v_MaHD, v_SL;
        EXIT WHEN curMaHD%NOTFOUND;
        
        update HOADON
        set ThanhTien = ThanhTien + v_SL * :new.Gia
        where MaHD = v_MaHD;
        
        update HOADON
        set ThanhTien = ThanhTien - v_SL * :old.Gia
        where MaHD = v_MaHD;
        
        select MAKH into v_MaKH
        from HOADON
        where MaHD = v_MaHD;
        
        if (v_MaKH is not null) then
            update KHACHHANG
            set DIEMTICHLUY = DIEMTICHLUY + v_SL * :new.Gia
            where MAKH = v_MAKH;
            
            update KHACHHANG
            set DIEMTICHLUY = DIEMTICHLUY - v_SL * :old.Gia
            where MAKH = v_MAKH;
            
            select DIEMTICHLUY into v_DTL
            from KHACHHANG
            where MAKH = v_MAKH;
            
            if (v_DTL >= 2000000) then
                update KHACHHANG
                set LOAIKH = 'VIP'
                where MAKH = v_MaKH;
            elsif (v_DTL >= 500000) then
                update KHACHHANG
                set LOAIKH = 'Thân Thiết'
                where MAKH = v_MaKH;
            elsif (v_DTL < 500000) then
                update KHACHHANG
                set LOAIKH = 'Thường'
                where MAKH = v_MaKH;
            end if;
        end if;
    END LOOP;
end;
/
create or replace trigger TRG_AUTO_SL_ThanhTien_DiemTL_CTHD_up
after update on CTHD
for each row
declare
    v_GiaSach number;
    v_GiaCTHDNew number;
    v_MaKH KHACHHANG.MAKH%type;
    v_DTL number;
begin
    select Gia into v_GiaSach
    from Sach
    where MaSach = :new.MaSach;
    
    update SACH
    set SL = SL - :new.SL
    where MaSach = :new.MaSach;
    
    v_GiaCTHDNew := :new.SL * v_GiaSach;
    
    update HOADON
    set ThanhTien = ThanhTien + v_GiaCTHDNew
    where MaHD = :new.MaHD;
    
    select MaKH into v_MaKH
    from HOADON
    where MaHD = :new.MaHD;
    if (v_MaKH is not null) then
        update KHACHHANG
        set DIEMTICHLUY = DIEMTICHLUY + v_GiaCTHDNew
        where MaKH = v_MaKH;
        
        select DIEMTICHLUY into v_DTL
        from KHACHHANG
        where MAKH = v_MaKH;
        
        if (v_DTL >= 2000000) then
            update KHACHHANG
            set LOAIKH = 'VIP'
            where MAKH = v_MaKH;
        elsif (v_DTL >= 500000) then
            update KHACHHANG
            set LOAIKH = 'Thân Thiết'
            where MAKH = v_MaKH;
        elsif (v_DTL < 500000) then
            update KHACHHANG
            set LOAIKH = 'Thường'
            where MAKH = v_MaKH;
        end if;
    end if;
end;
/
create or replace trigger TRG_AUTO_ThanhTien_DiemTL_CTHD_de_up
after delete or update on CTHD
for each row
declare
    v_GiaSach number;
    v_GiaCTHDOld number;
    v_MaKH KHACHHANG.MAKH%type;
    v_DTL number;
begin
    select Gia into v_GiaSach
    from Sach
    where MaSach = :old.MaSach;
    
    update SACH
    set SL = SL + :old.SL
    where MaSach = :old.MaSach;
    
    v_GiaCTHDOld := :old.SL * v_GiaSach;
    
    update HOADON
    set ThanhTien = ThanhTien - v_GiaCTHDOld
    where MaHD = :old.MaHD;
    
    select MaKH into v_MaKH
    from HOADON
    where MaHD = :old.MaHD;
    
    if (v_MaKH is not null) then
        update KHACHHANG
        set DIEMTICHLUY = DIEMTICHLUY - v_GiaCTHDOld
        where MaKH = v_MaKH;
        
        select DIEMTICHLUY into v_DTL
        from KHACHHANG
        where MAKH = v_MaKH;
        
        if (v_DTL >= 2000000) then
            update KHACHHANG
            set LOAIKH = 'VIP'
            where MAKH = v_MaKH;
        elsif (v_DTL >= 500000) then
            update KHACHHANG
            set LOAIKH = 'Thân Thiết'
            where MAKH = v_MaKH;
        elsif (v_DTL < 500000) then
            update KHACHHANG
            set LOAIKH = 'Thường'
            where MAKH = v_MaKH;
        end if;
    end if;
end;
/
create or replace trigger TRG_TongTienNhapSach_PhieuNhap_in
before insert on PHIEUNHAP
for each row
begin
    if (:new.TongTien != 0) then
        raise_application_error(-20011, 'Khi them moi 1 PhieuNhap tongtien = 0 (hệ thống sẽ tự động tính lại khi hoàn tất insert)');
    end if;
end;
/
create or replace trigger TRG_AUTO_SL_TongTienNhapSach_CTPN_up
after update on CTPN
for each row
begin
    update PHIEUNHAP
    set TongTien = TongTien + :new.SL * :new.Gia
    where MAPN = :new.MaPN;
    
    update SACH
    set SL = SL + :new.SL
    where MaSach = :new.MaSach;
end;
/
create or replace trigger TRG_AUTO_SL_TongTienNhapSach_CTPN_de_up
after delete or update on CTPN
for each row
declare
    v_SL number;
    v_TT number;
begin
    select SL into v_SL
    from SACH
    where MASACH = :old.MaSach;
    select TongTien into v_TT
    from PHIEUNHAP
    where MAPN = :old.MaPN;
    
    if (v_SL >= :old.SL) then
        update SACH
        set SL = SL - :old.SL
        where MaSach = :old.MaSach;
    end if;
    if (v_TT >= :old.SL * :old.Gia) then
        update PHIEUNHAP
        set TongTien = TongTien - :old.SL * :old.Gia
        where MAPN = :old.MaPN;
    end if;
end;

/
--INSERT NHACUNGCAP (MaNCC, TenNCC, DiaChi, SDT)
delete from NHACUNGCAP;
--select* from NHACUNGCAP;
insert into NHACUNGCAP(MaNCC, TenNCC, DiaChi, SDT) values(MANCC_SEQ1.nextval, N'Công Ty TNHH Văn Hoá Và Truyền Thông Trí Việt', N'Số 112 Ngõ 169 Phố Tây Sơn, Phường Quang Trung, Quận Đống đa, Hà Nội', '02435626332');
insert into NHACUNGCAP(MaNCC, TenNCC, DiaChi, SDT) values(MANCC_SEQ1.nextval, N'Nhà xuất bản Kim Đồng', N'55 Quang Trung, Hà Nội, Việt Nam', '02439434730');
insert into NHACUNGCAP(MaNCC, TenNCC, DiaChi, SDT) values(MANCC_SEQ1.nextval, N'Nhà xuất bản Trẻ', N'161B Lý Chính Thắng, Phường Võ Thị Sáu, Quận 3 , TP. Hồ Chí Minh', '02839316289');
insert into NHACUNGCAP(MaNCC, TenNCC, DiaChi, SDT) values(MANCC_SEQ1.nextval, N'Công ty cổ phần Văn hóa và Truyền thông Nhã Nam', '59 Đỗ Quang, KĐT Trung Hòa Nhân Chính, Cầu Giấy, Hà Nội', '02435146875');
insert into NHACUNGCAP(MaNCC, TenNCC, DiaChi, SDT) values(MANCC_SEQ1.nextval, N'Công ty cổ phần Giáo Dục Sputnik', 'Số 20, Ngõ 64 Dốc Thọ Lão, Phường Đống Mác, Quận Hai Bà Trưng, Hà Nội', '024339717152');
insert into NHACUNGCAP(MaNCC, TenNCC, DiaChi, SDT) values(MANCC_SEQ1.nextval, N'First News', '11H Nguyễn Thị Minh Khai, Phường Bến Nghé, Quận 1, Tp. Hồ Chí Minh', '02838227979');
insert into NHACUNGCAP(MaNCC, TenNCC, DiaChi, SDT) values(MANCC_SEQ1.nextval, N'Penguin Books', 'City of Westminster, London, London', '');
insert into NHACUNGCAP(MaNCC, TenNCC, DiaChi, SDT) values(MANCC_SEQ1.nextval, N'MCBooks', 'Số 45 đường 8, KP5, Hiệp Bình Chánh, Thủ Đức, TP Hồ Chí Minh', '02866609398');


-- INSERT THELOAI
delete from THELOAI;
--select* from THELOAI;
insert into THELOAI(MaTL, TheLoai, GhiChu) values(MATL_SEQ2.nextval, N'Tiểu thuyết', N'Tiểu thuyết là một thể loại văn xuôi có hư cấu, thông qua nhân vật, hoàn cảnh, sự việc để phản ánh bức tranh xã hội rộng lớn và những vấn đề của cuộc sống con người, biểu hiện tính chất tường thuật, tính chất kể chuyện bằng ngôn ngữ văn xuôi theo những chủ đề xác định.');
insert into THELOAI(MaTL, TheLoai, GhiChu) values(MATL_SEQ2.nextval, N'Manga', N'Manga là một cụm từ tiếng Nhật để chỉ các loại truyện tranh và tranh biếm họa của Nhật Bản. Bên ngoài Nhật Bản, Manga ám chỉ tính đặc trưng riêng biệt của truyện tranh Nhật Bản, hoặc như một phong cách truyện tranh phổ biến tại Nhật Bản mà thường được mô tả bởi đồ họa tràn đầy màu sắc, các nhân vật sống động và những chủ đề tuyệt vời.');
insert into THELOAI(MaTL, TheLoai, GhiChu) values(MATL_SEQ2.nextval, N'Văn học thiếu nhi', N'Văn học thiếu nhi bao gồm những câu chuyện, sách, tạp chí và những bài thơ được làm cho trẻ em. Văn học thiếu nhi hiện đại được phân loại theo hai cách khác nhau: thể loại hoặc nhắm tới độ tuổi của đối tượng độc giả.');
insert into THELOAI(MaTL, TheLoai, GhiChu) values(MATL_SEQ2.nextval, N'Tâm lý học', N'Tâm lý học là ngành khoa học nghiên cứu về tâm trí và hành vi, tìm hiểu về các hiện tượng ý thức và vô thức, cũng như cảm xúc và tư duy. Đây là một bộ môn học thuật với quy mô nghiên cứu rất sâu rộng.');
insert into THELOAI(MaTL, TheLoai, GhiChu) values(MATL_SEQ2.nextval, N'Kinh tế', N'Kinh tế là một lĩnh vực sản xuất, phân phối và thương mại, cũng như tiêu dùng hàng hóa và dịch vụ.');
insert into THELOAI(MaTL, TheLoai, GhiChu) values(MATL_SEQ2.nextval, N'Lịch sử', N'Lịch sử hay sử học là một môn khoa học nghiên cứu về quá khứ, đặc biệt là những sự kiện liên quan đến con người.');
insert into THELOAI(MaTL, TheLoai, GhiChu) values(MATL_SEQ2.nextval, N'Kiến thức khoa học', N'Khoa học là hệ thống kiến thức về những định luật, cấu trúc và cách vận hành của thế giới tự nhiên, được đúc kết qua từng giai đoạn lịch sử thông qua việc quan sát, mô tả, đo đạc, thực nghiệm, phát triển lý thuyết bằng các phương pháp khoa học.');
insert into THELOAI(MaTL, TheLoai, GhiChu) values(MATL_SEQ2.nextval, N'Kỹ năng sống', N'Kỹ năng sống là tập hợp các hành vi tích cực và khả năng thích nghi cho phép mỗi cá nhân đối phó hiệu quả với các nhu cầu và thách thức của cuộc sống hàng ngày; nói cách khác là khả năng tâm lý xã hội.');
insert into THELOAI(MaTL, TheLoai, GhiChu) values(MATL_SEQ2.nextval, N'Dinh dưỡng - Sức khỏe', N'Dinh dưỡng là việc cung cấp các chất cần thiết cho các tế bào và các sinh vật để hỗ trợ sự sống. Nó bao gồm các hoạt động ăn uống; hấp thu, vận chuyển và sử dụng các chất dinh dưỡng; bài tiết các chất thải.');
insert into THELOAI(MaTL, TheLoai, GhiChu) values(MATL_SEQ2.nextval, N'Sách học ngoại ngữ', N'Ngôn ngữ học hay ngữ lý học là bộ môn nghiên cứu về ngôn ngữ. Người nghiên cứu bộ môn này được gọi là nhà ngôn ngữ học. Nói theo nghĩa rộng, nó bao gồm ba khía cạnh: hình thái ngôn ngữ, nghĩa trong ngôn ngữ và ngôn ngữ trong ngữ cảnh.');

-- INSERT SACH
--select * from SACH;
delete from SACH;
insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Cuốn theo chiều gió', 1, N'Margaret Mitchell', '1/2/2012', N'Văn học', N'Bìa cứng', 'Lấy bối cảnh thời Nội chiến và tái thiết với các cuộc chiến ác liệt, những mâu thuẫn sâu sắc về chính trị, xã hội và cảnh đói nghèo sau chiến tranh, Cuốn theo chiều gió kể về Scarlett O’Hara, cô tiểu thư mắt xanh với dòng máu Ireland kiêu hãnh. Từ cô thiếu nữ mười sáu tuổi sống trong nhung lụa, bồng bột theo đuổi tình yêu, Scarlett đã đi qua những tháng ngày tuyệt vọng nhất, nếm trải mất mát, để cứu lấy mảnh đất Tara thân yêu, cứu lấy gia đình. Nhưng mặc cho phong ba bão táp của cuộc đời, nàng vẫn giữ đó niềm lạc quan vô tận.', 0, 215000, 1, N'Tiếng Việt', 'CuonTheoChieuGio.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Không gia đình', 1, N'Hector Malot', '2/3/2021', N'Văn học', N'Bìa cứng', N'KHÔNG GIA ĐÌNH kể về cuộc đời của cậu bé Rémi. Từ nhỏ, Rémi đã bị bắt cóc, rồi bị bố nuôi bán cho một đoàn xiếc thú. Em đã theo đoàn xiếc ấy đi lưu lạc khắp nước Pháp. Rémi đã lớn lên trong gian khổ và lao động để sống. Lúc đầu em được sự dạy bảo của cụ Vitalis, về sau thì tự lập. Không những lo cho mình, em còn lo việc biểu diễn và kiếm sống cho cả một gánh hát rong… Nhưng dù ở đâu, trong cảnh ngộ nào, em vẫn noi theo nếp rèn dạy của cụ Vitalis giữ phẩm chất làm người. Đó là lòng yêu lao động, tự trọng, ngay thẳng, biết nhớ ơn nghĩa và luôn luôn muốn làm người có ích.', 0, 119850, 1, N'Tiếng Việt', 'KhongGiaDinh.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Doraemon Truyện Dài - Tập 18 - Nobita Du Hành Biển Phương Nam', 2, N'FujikoFFujio', '5/2/2023', N'Kim Đồng', N'Bìa mềm', N'Mỗi tập truyện là một cuộc phưu lưu khám phá những chân trời mới lạ. Hãy để trí tưởng tượng của bạn bay bổng cùng nhóm bạn Doraemon, Nobita, Shizuka, Jaian, Suneo đến các vùng đất xa xôi, kì bí và cảm nhận những khoảnh khắc tình bạn tươi đẹp của cuộc đời!', 0, 19800, 2, N'Tiếng Việt', 'DoraemonTap18.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Nhóc Miko! Cô Bé Nhí Nhảnh - Tập 23', 2, N'ONO Eriko', '5/5/2020', N'NXB Trẻ', N'Bìa mềm', N'Tuy dáng người nhỏ nhắn, nhưng Miko là một cô nhóc cực kỳ khỏe khoắn năng động. Cuộc sống quanh cô nhóc lúc nào cũng rộn ràng. Mari ôm mộng làm họa sỹ truyện tranh, nên cùng Miko vẽ truyện gửi dự thi, mối quan hệ tay ba giữa Miko với Yoshida - thích Miko và Haruna - thích Yoshida... Hãy cùng thưởng thức tập truyện và sống vui tươi mỗi ngày giống Miko các bạn nhé!', 0, 18000, 3, N'Tiếng Việt', 'MikoTap23.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Hoàng tử bé', 3, N'Antoine De Saint-Exupéry', '12/1/2022', N'Hội Nhà Văn', N'Bìa mềm', N'Hoàng tử bé được viết ở New York trong những ngày tác giả sống lưu vong và được xuất bản lần đầu tiên tại New York vào năm 1943, rồi đến năm 1946 mới được xuất bản tại Pháp. Không nghi ngờ gì, đây là tác phẩm nổi tiếng nhất, được đọc nhiều nhất và cũng được yêu mến nhất của Saint-Exupéry. Cuốn sách được bình chọn là tác phẩm hay nhất thế kỉ 20 ở Pháp, đồng thời cũng là cuốn sách Pháp được dịch và được đọc nhiều nhất trên thế giới. Với 250 ngôn ngữ dịch khác nhau kể cả phương ngữ cùng hơn 200 triệu bản in trên toàn thế giới, Hoàng tử bé được coi là một trong những tác phẩm bán chạy nhất của nhân loại.', 0, 75000, 4, N'Tiếng Việt', 'HoangTuBeTiengViet.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Hoàng tử bé', 3, N'Antoine De Saint-Exupéry', '5/4/2019', N'Đại Học Quốc Gia Hà Nội', N'Bìa mềm', N'Hoàng tử bé được viết ở New York trong những ngày tác giả sống lưu vong và được xuất bản lần đầu tiên tại New York vào năm 1943, rồi đến năm 1946 mới được xuất bản tại Pháp. Không nghi ngờ gì, đây là tác phẩm nổi tiếng nhất, được đọc nhiều nhất và cũng được yêu mến nhất của Saint-Exupéry. Cuốn sách được bình chọn là tác phẩm hay nhất thế kỉ 20 ở Pháp, đồng thời cũng là cuốn sách Pháp được dịch và được đọc nhiều nhất trên thế giới. Với 250 ngôn ngữ dịch khác nhau kể cả phương ngữ cùng hơn 200 triệu bản in trên toàn thế giới, Hoàng tử bé được coi là một trong những tác phẩm bán chạy nhất của nhân loại.', 0, 80000, 5, N'Song ngữ Anh Việt', 'HoangTuBeSongNgu.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'How Psychology Works - Hiểu Hết Về Tâm Lý Học', 4, N'Jo Hemmings', '5/6/2022', N'Thế giới', N'Bìa mềm', N'MỘT TRONG NHỮNG CUỐN SÁCH MỞ KHÓA HỮU ÍCH NHẤT VỀ TƯ DUY, KÝ ỨC VÀ CẢM XÚC CỦA CON NGƯỜI! Ám sợ là gì, ám sợ có thực sự đáng sợ không? Rối loạn tâm lý là gì, làm thế nào để thoát khỏi tình trạng suy nhược và xáo trộn đó? Trầm cảm là gì, vì sao con người hiện đại thường xuyên gặp và chống chọi với tình trạng u uất, mệt mỏi và tuyệt vọng này?', 0, 300000, 4, N'Tiếng Việt', 'HieuHetVeTamLyHoc.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Người Giàu Có Nhất Thành Babylon', 5, N'George S Clason', '12/8/2020', N'NXB Tổng Hợp TPHCM', N'Bìa mềm', N'Những trang sách này sẽ đưa chúng ta trở lại vương quốc Babylon cổ đại, cái nôi nuôi dưỡng những nguyên lý cơ bản về tài chính mà giờ đây con người hiện đại đã kế thừa và vận dụng trên toàn thế giới.', 0, 98000, 6, N'Tiếng Việt', 'NguoiGiauCoNhatThanhBabylonylon.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Thank You for Being Late', 5, N'Thomas L. Friedman', '16/10/2017', N'Penguin Books Ltd', N'Bìa mềm', N'Friedman reveals the tectonic movements that are reshaping our world, how to adapt to this new age and why, sometimes, we all need to be late.''A master class ... As a guide for perplexed Westerners, this book is very hard to beat ... an honest, cohesive explanation for why the world is the way it is, without miracle cures or scapegoats'' John Micklethwait, The New York Times Book Review''Wonderful ... admirably honest ... injects a badly needed dose of optimism into the modern debate'' Gillian Tett, Financial Times''His main piece of advice for individuals, corporations, and countries is clear: Take a deep breath and adapt. This world isn''t going to wait for you'' Fortune''A humane and empathetic book'' David Henkin, The Washington Post ', 0, 333000, 7, N'Tiếng Anh', 'ThankYouForBeingLate.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Hồ Chí Minh Bàn Về Quân Sự', 6, N'Hồ Chí Minh', '6/10/2023', N'NXB Trẻ', N'Bìa mềm', N'Tư duy quân sự Hồ Chí Minh đậm chất “đem đại nghĩa để thắng hung tàn, lấy chí nhân để thay cường bạo”, trong đó nổi bật là nghệ thuật đánh địch bằng thế trận chiến tranh nhân dân; kết hợp chặt chẽ giữa tiến công quân sự với đấu tranh chính trị và ngoại giao; tiến công liên tục, đánh thắng từng bước, tiến tới giành thắng lợi hoàn toàn. Tư duy quân sự thiên tài đó bắt nguồn từ truyền thống anh hùng, bất khuất của dân tộc Việt Nam, và được làm phong phú thêm bởi khoa học quân sự nước ngoài.', 0, 89250, 3, N'Tiếng Việt', 'HCMBanVeQuanSu.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Lịch Sử Nước Ta', 6, N'Hồ Chí Minh', '4/10/2021', N'NXB Trẻ', N'Bìa mềm', N'Sau bao năm bôn ba tìm đường cứu nước, ngay sau khi Bác Hồ kính yêu vừa trở về nước tai Pác Bó, Người đã sáng tác bài Lịch sử nước ta. Đây là bài diễn ca lịch sử nước ta bằng thể thơ lục bát dễ thuộc, dễ hiểu gồm 208 câu. Đây là một tác phẩm giàu tâm huyết, có tác dụng rất lớn trong giáo dục lịch sử, truyền thống dành cho các bạn học sinh tham khảo và học tập.', 0, 68000, 3, N'Tiếng Việt', 'LichSuNuocTa.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Công Thức Hạnh Phúc', 8, N'Manfred F R Kets de Vries', '4/8/2020', N'NXB Thế Giới', N'Bìa mềm', N'Hạnh phúc thực ra là gì? Công thức nào tạo ra hạnh phúc? Trong cuốn sách này, Kets de Vries nỗ lực giải cấu trúc khái niệm trừu tượng ấy. Ông đi từ quan điểm sinh học, thống kê học, tâm lý học, triết học tự cổ chí kim đến cả các trích dẫn từ nhà văn, nhà thơ, nghệ sĩ, và trên hết, những trải nghiệm cá nhân, nhằm tìm ra một "đơn thuốc" giúp tăng cường khả năng đạt được hạnh phúc. Đơn thuốc ấy có hiệu quả hay không tùy thuộc ở mỗi người, nhưng có một điều chắc chắn: hạnh phúc luôn ở đâu đó, trong hiện tại và trong tương lai, và ta không bao giờ được mất hy vọng.', 0, 74800, 4, N'Tiếng Việt', 'CongThucHanhPhuc.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Chó Và Mèo Dưới Lăng Kính Khoa Học', 7, N'Antonio Fischetti', '4/5/2019', N'NXB Thế Giới', N'Bìa mềm', N'Bạn có nuôi chó hoặc mèo? Chắc hẳn là bạn rất thân thiết với người bạn bốn chân ấy. Vậy bạn có hiểu những hành vi, cử chỉ của “boss”? Chẳng hạn, tại sao chó lại vẫy đuôi cả khi vui mừng lẫn khi căng thẳng? Có nên nhìn thẳng vào mắt một con chó đang giận dữ? Những tiếng gừ gừ của mèo có ý nghĩa gì? Tại sao mèo lại khó tính với đồ ăn đến thế? Thông qua rất nhiều thí nghiệm, các bác sĩ thú y và nhà khoa học đã cố gắng giải mã những bí ẩn trong hành vi, thói quen… của chó và mèo, giúp ta hiểu thêm về những người bạn bốn chân này.', 0, 106250, 4, N'Tiếng Việt', 'ChoVaMeo.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Sổ Tay Ăn Dặm Của Mẹ', 9, N'BS Lê Thị Hải', '10/5/2020', N'NXB Thế Giới', N'Bìa mềm', N'“Trong quá trình khám chữa bệnh, tôi gặp nhiều trường hợp các em bé bị suy dinh dưỡng, còi xương không phải vì gia đình không có điều kiện mà do… quá có điều kiện. Tôi gặp những em bé khá bụ bẫm nhưng bố mẹ vẫn đưa đi khám vì thấy con không tăng cân và cho là con biếng ăn. Trong khi đó cũng có những trường hợp bố mẹ nói rằng con ăn rất được nhưng thực ra khẩu phần dinh dưỡng lại không đủ hoặc không cân đối. Nhưng biếng ăn là câu chuyện tôi gặp nhiều nhất. Chưa bao giờ câu chuyện cho bé ăn gì và ăn như thế nào lại khiến các bố mẹ lo lắng nhiều như vậy. Chính vì thế tôi viết cuốn sách Sổ tay ăn dặm của mẹ này với hi vọng có thể giải đáp được phần lớn thắc mắc của các bà mẹ khi cho con ăn dặm.” - Lê Thị Hải', 0, 84150, 4, N'Tiếng Việt', 'SoTayAnDamCuaMe.jpg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Chuyện Con Mèo Dạy Hải Âu Bay', 3, N'Luis Sepúlveda', '10/4/2019', N'NXB Hội Nhà Văn', N'Bìa mềm', N'Chuyện con mèo dạy hải âu bay là kiệt tác dành cho thiếu nhi của nhà văn Chi Lê nổi tiếng Luis Sepúlveda – tác giả của cuốn Lão già mê đọc truyện tình đã bán được 18 triệu bản khắp thế giới. Tác phẩm không chỉ là một câu chuyện ấm áp, trong sáng, dễ thương về loài vật mà còn chuyển tải thông điệp về trách nhiệm với môi trường, về sự sẻ chia và yêu thương cũng như ý nghĩa của những nỗ lực – “Chỉ những kẻ dám mới có thể bay”.', 0, 39200, 4, N'Tiếng Việt', 'ChuyenConMeoDayHaiAuBay.jpeg');

insert into SACH(MaSach, TenSach, MaTL, TenTG, NamXB, NXB, HinhThucBia, TomTat, SL, Gia, MaNCC, NgonNgu, HinhAnh) values (MASACH_SEQ3.nextval, N'Giáo Trình Tiếng Nhật Daichi Sơ Cấp 1', 10, N'Yamazaki Yoshiko, Ishii Reiko, Sasaki Kaoru, Takahashi Miwako, Machida Keiko', '10/4/2018', N'NXB Hồng Đức', N'Bìa mềm', N'Trong quá trình học tiếng Nhật, những cuốn giáo trình đóng vai trò quan trọng trong việc truyền tải kiến thức cũng như giúp các bạn định hướng được quá trình học tiếng Nhật về sau. Các bạn học tiếng Nhật đã quá quen thuộc với 2 bộ giáo trình Shin Nihongo no Kiso” và “Minna no Nihongo”. Bên cạnh 2 bộ giáo trình này bộ giáo trình “Nihongo shokyuu Daichi” cũng được rất nhiều người học tiếng Nhật yêu thích bởi độ hữu ích và thông dụng của nó.', 0, 144500, 8, N'Tiếng Việt', 'GiaoTrinhTiengNhat.jpg');

-- INSERT KHACHHANG
delete from KHACHHANG;
--select* from KHACHHANG;
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Văn', N'Trung', '18/01/2003', 'Nam', '0123748191');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Đặng Thị', N'Hà', '17/02/2003', N'Nữ', '0862718211');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Lê Thùy', N'Dương', '12/04/2002', N'Nữ', '0825187376');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn', N'Nam', '13/02/2003', 'Nam', '0163273829');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Huỳnh Tiến', N'Phong', '18/11/2003', 'Nam','0172937381');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Ngọc', N'Vy', '03/02/2000', N'Nữ', '0172839163');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Văn', N'Nam', '02/11/1998', 'Nam', '0789748191');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Lưu Hiếu', N'Ngân', '17/12/2000', N'Nữ', '0111182110');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Ánh', N'Dương', '12/09/2005', N'Nữ', '0825187789');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Trung', N'Nam', '13/02/1999', 'Nam', '0167893829');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Huỳnh Tiến', N'Đạt', '18/11/1994', 'Nam','0172937778');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Ngọc', N'Hân', '03/02/2001', N'Nữ', '0567839163');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Huỳnh Văn', N'Phong', '18/11/1997', 'Nam','0172234381');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Ngọc', N'Hân', '13/02/2000', N'Nữ', '0123439163');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Giang', N'Nam', '12/11/1996', 'Nam', '0345648191');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Lưu Ngọc', N'Ngân', '17/02/2000', N'Nữ', '0111222110');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Đặng Ánh', N'Tuyết', '12/09/2004', N'Nữ', '0825189998');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Trung', N'Dũng', '13/12/2006', 'Nam', '0167894429');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Huỳnh Lê Tiến', N'Đạt', '08/11/1974', 'Nam','0172347778');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Lê Cát', N'Tường', '03/12/2001', N'Nữ', '0567892163');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Văn', N'Dũng', '18/01/2003', 'Nam', '0123748191');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Lê Thị Ánh', N'Hà', '17/02/2003', N'Nữ', '0862718211');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Lê Nhựt', N'Trường', '12/04/2002', N'Nam', '0825187376');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Phạm Trọng', N'Tuấn', '13/02/2003', 'Nam', '0163273829');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Trần Hồng', N'Nhung', '18/11/2003', 'Nữ','0172937381');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Trần Ngọc', N'Như', '03/02/2000', N'Nữ', '0172839163');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Tiến', N'Phát', '02/11/1998', 'Nam', '0789748191');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Đỗ Thị', N'Hà', '17/12/2000', N'Nữ', '0111182110');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Hà', N'My', '12/09/2005', N'Nữ', '0825187789');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Lê Anh', N'Duy', '13/02/1999', 'Nam', '0167893829');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Kim', N'Ngân', '18/11/1994', 'Nữ','0172937778');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Ánh', N'Hồng', '03/02/2001', N'Nữ', '0567839163');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Hoàng', N'Phúc', '18/11/1997', 'Nam','0172234381');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Lê Bá Nhất', N'Long', '13/02/2000', N'Nam', '0123439163');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Hoàng', N'Việt', '12/11/1996', 'Nam', '0345648191');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Trương Ngọc', N'Châu', '17/02/2000', N'Nữ', '0111222110');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Thị Trà', N'My', '12/09/2004', N'Nữ', '0825189998');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Văn', N'Chương', '13/12/1977', 'Nam', '0167894429');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Nguyễn Việt', N'Hoàng', '08/11/1974', 'Nam','0172347778');
insert into KHACHHANG(MaKH, Ho, Ten, NgaySinh, GioiTinh, SoDT) values (MAKH_SEQ4.nextval, N'Võ Ngọc Lệ', N'Xuân', '03/12/2001', N'Nữ', '0567892163');


-- INSERT NHANVIEN
delete from NHANVIEN;
--select* from NHANVIEN;
insert into NHANVIEN(MaNV, Ho, Ten, GioiTinh, DiaChi, CMND, NgaySinh, NgayBD, SoDT, Luong, HinhAnh) values (MANV_SEQ5.nextval, N'Huỳnh Lê', N'Phong', 'Nam', 'Go Cong City', '272876897213', '17/06/2003', '1/5/2021' , '0912354665', '3500000','HuynhLePhong170603.PNG');
insert into NHANVIEN(MaNV, Ho, Ten, GioiTinh, DiaChi, CMND, NgaySinh, NgayBD, SoDT, Luong, HinhAnh) values (MANV_SEQ5.nextval, N'Nguyễn Triệu', N'Vy', N'Nữ', 'Pleiku City', '345234567821', '17/09/2003', '27/4/2021' , '0888843555', '4000000','NguyenTrieuVy170903.jpg');
insert into NHANVIEN(MaNV, Ho, Ten, GioiTinh, DiaChi, CMND, NgaySinh, NgayBD, SoDT, Luong, HinhAnh) values (MANV_SEQ5.nextval, N'Nguyễn Quốc', N'Trạng', 'Nam', 'Dong Nai Province', '272876897213', '18/01/2003', '28/04/2021' , '0912354665', '3000000','NguyenQuocTrang180103.jpg');
insert into NHANVIEN(MaNV, Ho, Ten, GioiTinh, DiaChi, CMND, NgaySinh, NgayBD, SoDT, Luong, HinhAnh) values (MANV_SEQ5.nextval, N'Đặng Lưu', N'Hà', N'Nữ', 'Binh Dinh Province', '345234567821', '17/02/2003', '25/4/2022' , '0888843555', '2500000', 'USERDEFAULT.png');
insert into NHANVIEN(MaNV, Ho, Ten, GioiTinh, DiaChi, CMND, NgaySinh, NgayBD, SoDT, Luong, HinhAnh) values (MANV_SEQ5.nextval, N'Lê Thùy', N'Dương', N'Nữ', 'Phu Yen Province', '345678567821', '12/04/2003', '25/4/2022' , '0888843777', '2500000', 'USERDEFAULT.png');

-- INSERT TAIKHOAN
delete from TAIKHOAN;
--select* from TAIKHOAN;
insert into TAIKHOAN(MaTK, TenTK, MatKhau, LoaiTK, MaNV) values (MATK_SEQ6.nextval, 'HuynhLePhong', '170603', 'nhan vien kho', 1);
insert into TAIKHOAN(MaTK, TenTK, MatKhau, LoaiTK, MaNV) values (MATK_SEQ6.nextval, 'NguyenTrieuVy', '170903', 'quan ly', 2);
insert into TAIKHOAN(MaTK, TenTK, MatKhau, LoaiTK, MaNV) values (MATK_SEQ6.nextval, 'NguyenQuocTrang', '180103', 'nhan vien ban hang', 3);
insert into TAIKHOAN(MaTK, TenTK, MatKhau, LoaiTK, MaNV) values (MATK_SEQ6.nextval, 'DangLuuHa', '170203', 'nhan vien ban hang', 4);
insert into TAIKHOAN(MaTK, TenTK, MatKhau, LoaiTK, MaNV) values (MATK_SEQ6.nextval, 'LeThuyDuong', '120403', 'nhan vien ban hang', 5);


-- INSERT PHIEUNHAP
--select* from PHIEUNHAP;
insert into PHIEUNHAP(MaPN, NgayNhap, TongTien, MaNV) values(MAPN_SEQ8.nextval, '10/05/2022', 0, 1); 
insert into PHIEUNHAP(MaPN, NgayNhap, TongTien, MaNV) values(MAPN_SEQ8.nextval, '11/05/2022', 0, 1); 
insert into PHIEUNHAP(MaPN, NgayNhap, TongTien, MaNV) values(MAPN_SEQ8.nextval, '12/05/2022', 0, 2); 
insert into PHIEUNHAP(MaPN, NgayNhap, TongTien, MaNV) values(MAPN_SEQ8.nextval, '13/05/2022', 0, 2); 
insert into PHIEUNHAP(MaPN, NgayNhap, TongTien, MaNV) values(MAPN_SEQ8.nextval, '14/05/2022', 0, 2); 
insert into PHIEUNHAP(MaPN, NgayNhap, TongTien, MaNV) values(MAPN_SEQ8.nextval, '15/05/2022', 0, 1); 
insert into PHIEUNHAP(MaPN, NgayNhap, TongTien, MaNV) values(MAPN_SEQ8.nextval, '16/05/2022', 0, 1); 
insert into PHIEUNHAP(MaPN, NgayNhap, TongTien, MaNV) values(MAPN_SEQ8.nextval, '17/05/2022', 0, 2); 
insert into PHIEUNHAP(MaPN, NgayNhap, TongTien, MaNV) values(MAPN_SEQ8.nextval, '18/05/2022', 0, 1); 
insert into PHIEUNHAP(MaPN, NgayNhap, TongTien, MaNV) values(MAPN_SEQ8.nextval, '19/05/2022', 0, 2); 
insert into PHIEUNHAP(MaPN, NgayNhap, TongTien, MaNV) values(MAPN_SEQ8.nextval, '19/05/2022', 0, 2); 


-- INSERT CTPN
--select* from CTPN;
exec sp_ThemCTPN(1, 1, 30, 165385);
exec sp_ThemCTPN(1, 2, 70, 92192);
exec sp_ThemCTPN(2, 1, 20, 165385);
exec sp_ThemCTPN(2, 2, 50, 92192);
exec sp_ThemCTPN(2, 3, 20, 15231);
exec sp_ThemCTPN(3, 3, 100, 15231);
exec sp_ThemCTPN(3, 4, 70, 13846);
exec sp_ThemCTPN(3, 5, 10, 57692);
exec sp_ThemCTPN(4, 3, 130, 15231);
exec sp_ThemCTPN(4, 4, 30, 13846);
exec sp_ThemCTPN(4, 5, 20, 57692);
exec sp_ThemCTPN(4, 6, 200, 62000);
exec sp_ThemCTPN(5, 6, 250, 62000);
exec sp_ThemCTPN(5, 7, 50, 230000);
exec sp_ThemCTPN(6, 6, 20, 62000);
exec sp_ThemCTPN(6, 7, 100, 230000);
exec sp_ThemCTPN(6, 8, 60, 76000);
exec sp_ThemCTPN(7, 9, 100, 257000);
exec sp_ThemCTPN(7, 13, 100, 82000);
exec sp_ThemCTPN(7, 14, 30, 64731);
exec sp_ThemCTPN(8, 9, 136, 257000);
exec sp_ThemCTPN(8, 15, 46, 30154);
exec sp_ThemCTPN(9, 16, 250, 111154);
exec sp_ThemCTPN(8, 10, 20, 68654);
exec sp_ThemCTPN(9, 15, 170, 30154);
exec sp_ThemCTPN(10, 11, 70, 52308);
exec sp_ThemCTPN(10, 12, 60, 57539);

-- INSERT HOADON
--select * from HOADON;
delete from HOADON;
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/08/2022', 3, 2, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/08/2022', 3, 1, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/08/2022', 3, 3, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/08/2022', 4, 4, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/08/2022', 4, 6, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '02/08/2022', 5, 7, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '02/08/2022', 5, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '02/08/2022', 3, 8, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '02/08/2022', 4, 5, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/08/2022', 3, 11, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/08/2022', 4, 4, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/08/2022', 4, 12, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/08/2022', 4, 13, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/08/2022', 3, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/08/2022', 3, 14, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/08/2022', 4, 17, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/08/2022', 4, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/08/2022', 5, 5, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/08/2022', 5, 4, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/08/2022', 3, 1, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/08/2022', 3, 18, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/08/2022', 3, 20, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/08/2022', 3, 19, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/08/2022', 4, 6, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/08/2022', 4, 21, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/08/2022', 3, 22, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/08/2022', 3, 24, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/08/2022', 3, 26, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/08/2022', 4, 23, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/08/2022', 4, 25, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/08/2022', 4, 28, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/08/2022', 4, 27, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '08/08/2022', 4, 29, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '08/08/2022', 5, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '08/08/2022', 3, 30, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/08/2022', 4, 17, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/08/2022', 4, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/08/2022', 4, 3, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/08/2022', 4, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/08/2022', 4, 31, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/08/2022', 3, 32, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/08/2022', 3, 2, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/08/2022', 5, 33, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/08/2022', 5, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '12/08/2022', 3, 35, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '13/08/2022', 4, 6, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/08/2022', 3, 7, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/08/2022', 3, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/08/2022', 3, 36, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/08/2022', 4, 37, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '16/08/2022', 3, 11, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '17/08/2022', 4, 24, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '18/08/2022', 4, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '18/08/2022', 4, 3, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '19/08/2022', 3, 38, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/08/2022', 3, 28, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/08/2022', 5, 17, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/08/2022', 4, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/08/2022', 4, 35, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '22/08/2022', 3, 39, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/08/2022', 3, 40, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/08/2022', 3, 19, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '24/08/2022', 5, 21, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '25/08/2022', 3, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '26/08/2022', 4, 6, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '26/08/2022', 4, 24, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '27/08/2022', 3, 25, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '28/08/2022', 5, 29, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '29/08/2022', 3, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '30/08/2022', 4, 21, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '31/08/2022', 4, 25, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/09/2022', 4, 28, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/09/2022', 4, 27, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '02/09/2022', 5, 29, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/09/2022', 3, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/09/2022', 3, 30, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/09/2022', 4, 40, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/09/2022', 4, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/09/2022', 4, 7, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/09/2022', 5, 36, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '08/09/2022', 4, 31, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/09/2022', 3, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/09/2022', 3, 2, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/09/2022', 3, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/09/2022', 4, 3, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/09/2022', 3, 38, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '12/09/2022', 3, 30, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '13/09/2022', 4, 6, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/09/2022', 3, 17, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/09/2022', 3, 29, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/09/2022', 3, 3, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/09/2022', 4, 37, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '16/09/2022', 3, 1, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '17/09/2022', 5, 4, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '18/09/2022', 4, 12, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '18/09/2022', 4, 3, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '19/09/2022', 3, 38, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/09/2022', 3, 28, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/09/2022', 4, 17, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/09/2022', 4, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/09/2022', 4, 35, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '22/09/2022', 5, 39, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/09/2022', 3, 40, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/09/2022', 3, 19, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '24/09/2022', 3, 21, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '25/09/2022', 3, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '26/09/2022', 4, 26, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '26/09/2022', 4, 4, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '27/09/2022', 3, 2, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '28/09/2022', 5, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '29/09/2022', 5, 14, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '30/09/2022', 4, 11, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/10/2022', 4, 38, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/10/2022', 4, 12, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '02/10/2022', 4, 39, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/10/2022', 3, 25, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/10/2022', 3, 20, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/10/2022', 4, 40, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/10/2022', 4, 6, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/10/2022', 4, 8, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/10/2022', 5, 26, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '08/10/2022', 5, 11, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/10/2022', 3, 14, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/10/2022', 3, 25, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/10/2022', 3, 29, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/10/2022', 4, 31, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/10/2022', 3, 32, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '12/10/2022', 5, 30, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '13/10/2022', 4, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/10/2022', 3, 8, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/10/2022', 3, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/10/2022', 3, 33, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/10/2022', 4, 27, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '16/10/2022', 3, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '17/10/2022', 4, 24, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '18/10/2022', 4, 2, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '18/10/2022', 4, 33, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/10/2022', 3, 38, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/10/2022', 3, 8, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/10/2022', 4, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/10/2022', 4, 13, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/10/2022', 4, 35, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '22/10/2022', 5, 39, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/10/2022', 3, 40, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/10/2022', 3, 13, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '24/10/2022', 3, 26, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '25/10/2022', 3, 30, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '26/10/2022', 4, 26, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '26/10/2022', 4, 40, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '27/10/2022', 5, 2, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '28/10/2022', 3, 19, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '29/10/2022', 3, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '30/10/2022', 4, 1, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '31/10/2022', 4, 32, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/11/2022', 4, 39, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '02/11/2022', 4, 40, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/11/2022', 3, 26, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/11/2022', 3, 21, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/11/2022', 4, 39, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/11/2022', 4, 7, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/11/2022', 4, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '08/11/2022', 4, 12, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/11/2022', 3, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/11/2022', 3, 26, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/11/2022', 4, 32, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '12/11/2022', 3, 31, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '13/11/2022', 4, 18, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/11/2022', 3, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/11/2022', 3, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '16/11/2022', 3, 17, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '17/11/2022', 4, 27, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '18/11/2022', 4, 3, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '19/11/2022', 3, 39, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/11/2022', 3, 8, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/11/2022', 4, 13, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '22/11/2022', 3, 39, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/11/2022', 3, 40, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '24/11/2022', 3, 26, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '25/11/2022', 3, 36, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '26/11/2022', 4, 21, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '27/11/2022', 3, 2, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '28/11/2022', 3, 12, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '29/11/2022', 3, 36, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '30/11/2022', 4, 4, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/12/2022', 4, 33, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '02/12/2022', 4, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/12/2022', 3, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/12/2022', 3, 25, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/12/2022', 4, 37, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/12/2022', 4, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/12/2022', 4, 10, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '08/12/2022', 4, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/12/2022', 3, 17, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/12/2022', 3, 28, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/12/2022', 4, 30, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '12/12/2022', 3, 31, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '13/12/2022', 5, 11, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/12/2022', 3, 2, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/12/2022', 3, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '16/12/2022', 3, 17, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '17/12/2022', 4, 27, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '18/12/2022', 4, 3, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '19/12/2022', 3, 32, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/12/2022', 3, 6, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/12/2022', 4, 12, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '22/12/2022', 3, 35, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/12/2022', 3, 21, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '24/12/2022', 3, 23, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '25/12/2022', 3, 35, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '26/12/2022', 4, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '27/12/2022', 3, 2, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '28/12/2022', 3, 14, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '29/12/2022', 3, 37, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '30/12/2022', 4, 3, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '31/12/2022', 3, 1, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/01/2023', 4, 33, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '02/01/2023', 4, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/01/2023', 3, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/01/2023', 3, 25, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/01/2023', 4, 37, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/01/2023', 4, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/01/2023', 4, 10, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '08/01/2023', 4, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/01/2023', 3, 17, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/01/2023', 3, 28, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/01/2023', 4, 30, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '12/01/2023', 3, 31, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '13/01/2023', 4, 11, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/01/2023', 3, 2, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/01/2023', 3, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '16/01/2023', 3, 17, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '17/01/2023', 4, 27, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '18/01/2023', 4, 3, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '19/01/2023', 3, 32, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/01/2023', 3, 6, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/01/2023', 4, 12, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '22/01/2023', 3, 35, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/01/2023', 3, 21, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '24/01/2023', 3, 23, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '25/01/2023', 3, 35, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '26/01/2023', 4, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '27/01/2023', 3, 2, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '28/01/2023', 3, 14, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '29/01/2023', 3, 37, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '30/01/2023', 4, 3, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '31/01/2023', 3, 1, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/02/2023', 4, 33, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '02/02/2023', 4, 31, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/02/2023', 3, 12, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/02/2023', 3, 25, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/02/2023', 4, 27, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/02/2023', 4, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/02/2023', 4, 10, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '08/02/2023', 4, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/02/2023', 3, 17, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/02/2023', 3, 38, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/02/2023', 4, 30, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '12/02/2023', 3, 31, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '13/02/2023', 4, 11, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/02/2023', 3, 2, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/02/2023', 3, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '16/02/2023', 3, 17, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '17/02/2023', 4, 27, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '18/02/2023', 4, 4, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '19/02/2023', 3, 32, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/02/2023', 3, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/02/2023', 4, 2, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '22/02/2023', 3, 35, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/02/2023', 3, 21, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '24/02/2023', 3, 23, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '25/02/2023', 3, 5, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '26/02/2023', 4, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '27/02/2023', 3, 2, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '28/02/2023', 3, 24, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/03/2023', 4, 33, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '02/03/2023', 4, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/03/2023', 3, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/03/2023', 3, 40, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/03/2023', 4, 37, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/03/2023', 4, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/03/2023', 4, 10, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '08/03/2023', 4, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/03/2023', 3, 20, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/03/2023', 3, 28, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/03/2023', 4, 32, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '12/03/2023', 3, 31, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '13/03/2023', 4, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/03/2023', 3, 23, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/03/2023', 3, 4, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '16/03/2023', 3, 17, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '17/03/2023', 4, 37, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '18/03/2023', 4, 3, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '19/03/2023', 3, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/03/2023', 3, 6, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/03/2023', 4, 12, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '22/03/2023', 3, 5, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/03/2023', 3, 21, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '24/03/2023', 3, 23, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '25/03/2023', 3, 35, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '26/03/2023', 4, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '27/03/2023', 3, 2, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '28/03/2023', 3, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '29/03/2023', 3, 33, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '30/03/2023', 4, 13, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '31/03/2023', 3, 2, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/04/2023', 4, 33, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '02/04/2023', 4, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/04/2023', 3, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/04/2023', 3, 40, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/04/2023', 4, 37, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '06/04/2023', 4, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/04/2023', 4, 10, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '08/04/2023', 4, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/04/2023', 3, 20, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/04/2023', 3, 28, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/04/2023', 4, 32, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '12/04/2023', 3, 31, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '13/04/2023', 4, 18, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/04/2023', 3, 23, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/04/2023', 5, 40, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '16/04/2023', 3, 12, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '17/04/2023', 4, 37, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '17/04/2023', 4, 35, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '19/04/2023', 3, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/04/2023', 3, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '20/04/2023', 4, 12, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '22/04/2023', 3, 5, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/04/2023', 3, 21, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/04/2023', 3, 23, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '25/04/2023', 3, 35, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '27/04/2023', 4, 12, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '27/04/2023', 3, 2, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '28/04/2023', 3, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '29/04/2023', 3, 33, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '30/04/2023', 4, 16, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/05/2023', 4, 33, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '01/05/2023', 5, 34, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '03/05/2023', 3, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '04/05/2023', 3, 40, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '05/05/2023', 4, 37, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/05/2023', 4, 9, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '07/05/2023', 4, 10, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '08/05/2023', 4, 15, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '09/05/2023', 3, 20, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '10/05/2023', 3, 28, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/05/2023', 4, 32, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '11/05/2023', 3, 31, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '13/05/2023', 4, 18, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '14/05/2023', 3, 23, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '15/05/2023', 3, 40, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '16/05/2023', 3, 23, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '17/05/2023', 4, 37, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '18/05/2023', 4, 35, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '19/05/2023', 3, 22, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/05/2023', 3, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/05/2023', 4, 12, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '21/05/2023', 3, 5, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '23/05/2023', 5, 21, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '24/05/2023', 5, 23, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '25/05/2023', 3, 35, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '26/05/2023', 4, 12, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '27/05/2023', 3, 2, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '28/05/2023', 3, 16, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '29/05/2023', 3, 33, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '30/05/2023', 5, 16, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '31/05/2023', 3, 39, 0); 
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '31/05/2023', 4, 19, 0);
insert into HOADON(MaHD, NgayHD, MaNV, MaKH, ThanhTien) values (MAHD_SEQ7.nextval, '31/05/2023', 3, 2, 0);

-- CTHD
--select * from CTHD; 
delete from CTHD;
exec sp_ThemCTHD(1, 1, 1);
exec sp_ThemCTHD(1, 2, 1);
exec sp_ThemCTHD(2, 1, 1);
exec sp_ThemCTHD(2, 3, 1);
exec sp_ThemCTHD(3, 2, 1);
exec sp_ThemCTHD(3, 3, 2);
exec sp_ThemCTHD(4, 2, 1);
exec sp_ThemCTHD(4, 4, 1);
exec sp_ThemCTHD(5, 4, 1);
exec sp_ThemCTHD(5, 5, 2);
exec sp_ThemCTHD(5, 6, 1);
exec sp_ThemCTHD(6, 1, 1);
exec sp_ThemCTHD(6, 7, 1);
exec sp_ThemCTHD(6, 6, 1);
exec sp_ThemCTHD(7, 2, 2);
exec sp_ThemCTHD(7, 3, 1);
exec sp_ThemCTHD(7, 4, 2);
exec sp_ThemCTHD(8, 7, 3);
exec sp_ThemCTHD(8, 6, 1);
exec sp_ThemCTHD(9, 8, 1);
exec sp_ThemCTHD(10, 9, 1);
exec sp_ThemCTHD(10, 13, 1);
exec sp_ThemCTHD(10, 14, 1);
exec sp_ThemCTHD(11, 9, 2);
exec sp_ThemCTHD(11, 15, 1);
exec sp_ThemCTHD(11, 16, 2);
exec sp_ThemCTHD(12, 2, 2);
exec sp_ThemCTHD(12, 3, 1);
exec sp_ThemCTHD(12, 4, 2);
exec sp_ThemCTHD(13, 2, 1);
exec sp_ThemCTHD(13, 3, 1);
exec sp_ThemCTHD(14, 7, 3);
exec sp_ThemCTHD(14, 6, 1);
exec sp_ThemCTHD(15, 10, 1);
exec sp_ThemCTHD(16, 10, 1);
exec sp_ThemCTHD(16, 11, 2);
exec sp_ThemCTHD(17, 7, 1);
exec sp_ThemCTHD(17, 12, 1);
exec sp_ThemCTHD(18, 9, 1);
exec sp_ThemCTHD(18, 13, 1);
exec sp_ThemCTHD(18, 14, 1);
exec sp_ThemCTHD(19, 2, 1);
exec sp_ThemCTHD(19, 4, 1);
exec sp_ThemCTHD(20, 8, 1);
exec sp_ThemCTHD(21, 1, 1);
exec sp_ThemCTHD(21, 2, 2);
exec sp_ThemCTHD(22, 2, 1);
exec sp_ThemCTHD(22, 3, 3);
exec sp_ThemCTHD(23, 2, 1);
exec sp_ThemCTHD(23, 3, 2);
exec sp_ThemCTHD(24, 2, 1);
exec sp_ThemCTHD(24, 4, 4);
exec sp_ThemCTHD(25, 4, 1);
exec sp_ThemCTHD(25, 5, 2);
exec sp_ThemCTHD(25, 6, 1);
exec sp_ThemCTHD(26, 1, 1);
exec sp_ThemCTHD(26, 7, 3);
exec sp_ThemCTHD(26, 6, 1);
exec sp_ThemCTHD(27, 2, 2);
exec sp_ThemCTHD(27, 3, 1);
exec sp_ThemCTHD(27, 4, 2);
exec sp_ThemCTHD(28, 7, 3);
exec sp_ThemCTHD(28, 6, 1);
exec sp_ThemCTHD(29, 8, 1);
exec sp_ThemCTHD(30, 9, 4);
exec sp_ThemCTHD(30, 13, 1);
exec sp_ThemCTHD(30, 14, 1);
exec sp_ThemCTHD(31, 9, 2);
exec sp_ThemCTHD(31, 15, 1);
exec sp_ThemCTHD(32, 16, 2);
exec sp_ThemCTHD(33, 2, 2);
exec sp_ThemCTHD(34, 3, 1);
exec sp_ThemCTHD(35, 4, 2);
exec sp_ThemCTHD(36, 2, 1);
exec sp_ThemCTHD(36, 3, 1);
exec sp_ThemCTHD(37, 7, 3);
exec sp_ThemCTHD(37, 6, 1);
exec sp_ThemCTHD(38, 10, 1);
exec sp_ThemCTHD(38, 15, 1);
exec sp_ThemCTHD(39, 11, 2);
exec sp_ThemCTHD(40, 7, 1);
exec sp_ThemCTHD(41, 12, 2);
exec sp_ThemCTHD(42, 9, 1);
exec sp_ThemCTHD(43, 13, 1);
exec sp_ThemCTHD(43, 14, 1);
exec sp_ThemCTHD(44, 2, 1);
exec sp_ThemCTHD(45, 4, 3);
exec sp_ThemCTHD(46, 8, 1);
exec sp_ThemCTHD(47, 1, 1);
exec sp_ThemCTHD(48, 2, 2);
exec sp_ThemCTHD(49, 1, 2);
exec sp_ThemCTHD(50, 3, 1);
exec sp_ThemCTHD(51, 2, 1);
exec sp_ThemCTHD(52, 3, 1);
exec sp_ThemCTHD(52, 2, 1);
exec sp_ThemCTHD(53, 4, 1);
exec sp_ThemCTHD(53, 8, 2);
exec sp_ThemCTHD(54, 5, 1);
exec sp_ThemCTHD(55, 6, 3);
exec sp_ThemCTHD(56, 1, 1);
exec sp_ThemCTHD(57, 7, 1);
exec sp_ThemCTHD(58, 6, 1);
exec sp_ThemCTHD(59, 2, 2);
exec sp_ThemCTHD(60, 3, 1);
exec sp_ThemCTHD(61, 4, 2);
exec sp_ThemCTHD(62, 7, 3);
exec sp_ThemCTHD(63, 6, 1);
exec sp_ThemCTHD(64, 8, 1);
exec sp_ThemCTHD(65, 9, 1);
exec sp_ThemCTHD(65, 13, 1);
exec sp_ThemCTHD(66, 14, 1);
exec sp_ThemCTHD(67, 9, 2);
exec sp_ThemCTHD(68, 15, 1);
exec sp_ThemCTHD(69, 16, 2);
exec sp_ThemCTHD(70, 2, 2);
exec sp_ThemCTHD(71, 3, 1);
exec sp_ThemCTHD(72, 4, 2);
exec sp_ThemCTHD(73, 2, 1);
exec sp_ThemCTHD(73, 3, 1);
exec sp_ThemCTHD(74, 7, 3);
exec sp_ThemCTHD(74, 6, 1);
exec sp_ThemCTHD(75, 10, 2);
exec sp_ThemCTHD(76, 16, 1);
exec sp_ThemCTHD(76, 11, 2);
exec sp_ThemCTHD(77, 7, 1);
exec sp_ThemCTHD(78, 12, 1);
exec sp_ThemCTHD(79, 9, 1);
exec sp_ThemCTHD(80, 13, 5);
exec sp_ThemCTHD(81, 14, 1);
exec sp_ThemCTHD(82, 2, 1);
exec sp_ThemCTHD(83, 4, 1);
exec sp_ThemCTHD(83, 8, 4);
exec sp_ThemCTHD(84, 1, 1);
exec sp_ThemCTHD(85, 2, 2);
exec sp_ThemCTHD(86, 15, 1);
exec sp_ThemCTHD(87, 3, 3);
exec sp_ThemCTHD(88, 2, 1);
exec sp_ThemCTHD(89, 3, 2);
exec sp_ThemCTHD(90, 2, 1);
exec sp_ThemCTHD(91, 4, 4);
exec sp_ThemCTHD(92, 16, 1);
exec sp_ThemCTHD(93, 5, 2);
exec sp_ThemCTHD(94, 6, 1);
exec sp_ThemCTHD(95, 1, 1);
exec sp_ThemCTHD(96, 7, 3);
exec sp_ThemCTHD(96, 6, 1);
exec sp_ThemCTHD(97, 2, 2);
exec sp_ThemCTHD(97, 3, 1);
exec sp_ThemCTHD(98, 4, 2);
exec sp_ThemCTHD(99, 7, 3);
exec sp_ThemCTHD(100, 6, 1);
exec sp_ThemCTHD(101, 8, 1);
exec sp_ThemCTHD(102, 9, 4);
exec sp_ThemCTHD(102, 13, 1);
exec sp_ThemCTHD(103, 14, 1);
exec sp_ThemCTHD(104, 9, 2);
exec sp_ThemCTHD(105, 15, 5);
exec sp_ThemCTHD(106, 16, 4);
exec sp_ThemCTHD(107, 2, 2);
exec sp_ThemCTHD(108, 3, 1);
exec sp_ThemCTHD(109, 4, 2);
exec sp_ThemCTHD(109, 2, 1);
exec sp_ThemCTHD(110, 3, 1);
exec sp_ThemCTHD(111, 7, 3);
exec sp_ThemCTHD(111, 6, 1);
exec sp_ThemCTHD(112, 10, 1);
exec sp_ThemCTHD(113, 13, 3);
exec sp_ThemCTHD(114, 11, 2);
exec sp_ThemCTHD(115, 7, 1);
exec sp_ThemCTHD(116, 12, 2);
exec sp_ThemCTHD(117, 9, 1);
exec sp_ThemCTHD(118, 13, 1);
exec sp_ThemCTHD(118, 14, 1);
exec sp_ThemCTHD(119, 2, 1);
exec sp_ThemCTHD(120, 4, 3);
exec sp_ThemCTHD(121, 8, 1);
exec sp_ThemCTHD(122, 1, 1);
exec sp_ThemCTHD(123, 2, 1);
exec sp_ThemCTHD(124, 1, 1);
exec sp_ThemCTHD(125, 3, 1);
exec sp_ThemCTHD(125, 2, 1);
exec sp_ThemCTHD(126, 3, 1);
exec sp_ThemCTHD(127, 2, 1);
exec sp_ThemCTHD(128, 4, 1);
exec sp_ThemCTHD(129, 12, 1);
exec sp_ThemCTHD(130, 5, 1);
exec sp_ThemCTHD(131, 6, 1);
exec sp_ThemCTHD(131, 1, 1);
exec sp_ThemCTHD(132, 7, 1);
exec sp_ThemCTHD(133, 6, 1);
exec sp_ThemCTHD(134, 2, 2);
exec sp_ThemCTHD(135, 3, 1);
exec sp_ThemCTHD(136, 4, 2);
exec sp_ThemCTHD(137, 7, 3);
exec sp_ThemCTHD(137, 6, 1);
exec sp_ThemCTHD(138, 8, 1);
exec sp_ThemCTHD(139, 9, 1);
exec sp_ThemCTHD(140, 13, 1);
exec sp_ThemCTHD(141, 14, 1);
exec sp_ThemCTHD(142, 9, 2);
exec sp_ThemCTHD(143, 15, 1);
exec sp_ThemCTHD(144, 16, 2);
exec sp_ThemCTHD(145, 2, 2);
exec sp_ThemCTHD(146, 3, 1);
exec sp_ThemCTHD(147, 4, 2);
exec sp_ThemCTHD(148, 2, 1);
exec sp_ThemCTHD(149, 3, 1);
exec sp_ThemCTHD(150, 7, 3);
exec sp_ThemCTHD(151, 6, 1);
exec sp_ThemCTHD(152, 10, 1);
exec sp_ThemCTHD(152, 13, 4);
exec sp_ThemCTHD(153, 11, 2);
exec sp_ThemCTHD(154, 7, 1);
exec sp_ThemCTHD(155, 12, 1);
exec sp_ThemCTHD(156, 9, 1);
exec sp_ThemCTHD(157, 12, 1);
exec sp_ThemCTHD(157, 14, 1);
exec sp_ThemCTHD(158, 2, 1);
exec sp_ThemCTHD(159, 4, 1);
exec sp_ThemCTHD(160, 8, 1);
exec sp_ThemCTHD(161, 1, 1);
exec sp_ThemCTHD(162, 2, 2);
exec sp_ThemCTHD(163, 9, 1);
exec sp_ThemCTHD(164, 3, 3);
exec sp_ThemCTHD(165, 2, 1);
exec sp_ThemCTHD(166, 3, 2);
exec sp_ThemCTHD(167, 2, 1);
exec sp_ThemCTHD(168, 4, 4);
exec sp_ThemCTHD(169, 8, 1);
exec sp_ThemCTHD(170, 5, 2);
exec sp_ThemCTHD(171, 6, 1);
exec sp_ThemCTHD(172, 1, 1);
exec sp_ThemCTHD(173, 7, 3);
exec sp_ThemCTHD(174, 6, 1);
exec sp_ThemCTHD(175, 2, 2);
exec sp_ThemCTHD(176, 3, 1);
exec sp_ThemCTHD(177, 4, 2);
exec sp_ThemCTHD(178, 7, 3);
exec sp_ThemCTHD(179, 6, 1);
exec sp_ThemCTHD(180, 8, 1);
exec sp_ThemCTHD(181, 9, 4);
exec sp_ThemCTHD(182, 13, 1);
exec sp_ThemCTHD(182, 14, 1);
exec sp_ThemCTHD(183, 9, 2);
exec sp_ThemCTHD(184, 15, 1);
exec sp_ThemCTHD(184, 16, 2);
exec sp_ThemCTHD(185, 2, 2);
exec sp_ThemCTHD(186, 3, 1);
exec sp_ThemCTHD(187, 4, 2);
exec sp_ThemCTHD(188, 2, 1);
exec sp_ThemCTHD(189, 3, 1);
exec sp_ThemCTHD(190, 7, 3);
exec sp_ThemCTHD(191, 6, 1);
exec sp_ThemCTHD(192, 10, 1);
exec sp_ThemCTHD(193, 15, 1);
exec sp_ThemCTHD(194, 11, 2);
exec sp_ThemCTHD(195, 7, 1);
exec sp_ThemCTHD(196, 12, 2);
exec sp_ThemCTHD(197, 9, 1);
exec sp_ThemCTHD(198, 13, 1);
exec sp_ThemCTHD(199, 14, 1);
exec sp_ThemCTHD(200, 2, 1);
exec sp_ThemCTHD(201, 4, 3);
exec sp_ThemCTHD(202, 8, 1);
exec sp_ThemCTHD(203, 1, 1);
exec sp_ThemCTHD(204, 2, 2);
exec sp_ThemCTHD(204, 1, 2);
exec sp_ThemCTHD(205, 3, 1);
exec sp_ThemCTHD(206, 2, 1);
exec sp_ThemCTHD(207, 3, 1);
exec sp_ThemCTHD(208, 2, 2);
exec sp_ThemCTHD(209, 4, 1);
exec sp_ThemCTHD(210, 7, 2);
exec sp_ThemCTHD(211, 5, 1);
exec sp_ThemCTHD(212, 6, 3);
exec sp_ThemCTHD(213, 1, 1);
exec sp_ThemCTHD(214, 7, 1);
exec sp_ThemCTHD(215, 6, 1);
exec sp_ThemCTHD(216, 2, 2);
exec sp_ThemCTHD(217, 3, 1);
exec sp_ThemCTHD(218, 4, 2);
exec sp_ThemCTHD(219, 7, 3);
exec sp_ThemCTHD(220, 6, 1);
exec sp_ThemCTHD(221, 8, 1);
exec sp_ThemCTHD(222, 9, 1);
exec sp_ThemCTHD(223, 13, 1);
exec sp_ThemCTHD(224, 14, 1);
exec sp_ThemCTHD(225, 9, 2);
exec sp_ThemCTHD(226, 15, 3);
exec sp_ThemCTHD(227, 16, 2);
exec sp_ThemCTHD(228, 2, 2);
exec sp_ThemCTHD(229, 3, 1);
exec sp_ThemCTHD(230, 4, 2);
exec sp_ThemCTHD(231, 2, 1);
exec sp_ThemCTHD(232, 3, 1);
exec sp_ThemCTHD(233, 7, 3);
exec sp_ThemCTHD(234, 6, 1);
exec sp_ThemCTHD(235, 10, 1);
exec sp_ThemCTHD(236, 10, 1);
exec sp_ThemCTHD(237, 11, 2);
exec sp_ThemCTHD(238, 7, 1);
exec sp_ThemCTHD(239, 12, 1);
exec sp_ThemCTHD(240, 9, 1);
exec sp_ThemCTHD(241, 13, 5);
exec sp_ThemCTHD(241, 14, 1);
exec sp_ThemCTHD(241, 2, 1);
exec sp_ThemCTHD(242, 4, 1);
exec sp_ThemCTHD(243, 8, 4);
exec sp_ThemCTHD(244, 1, 1);
exec sp_ThemCTHD(245, 2, 2);
exec sp_ThemCTHD(246, 9, 1);
exec sp_ThemCTHD(247, 3, 3);
exec sp_ThemCTHD(248, 2, 1);
exec sp_ThemCTHD(249, 3, 2);
exec sp_ThemCTHD(250, 2, 1);
exec sp_ThemCTHD(251, 4, 4);
exec sp_ThemCTHD(251, 10, 1);
exec sp_ThemCTHD(252, 5, 2);
exec sp_ThemCTHD(253, 6, 1);
exec sp_ThemCTHD(254, 1, 1);
exec sp_ThemCTHD(255, 7, 3);
exec sp_ThemCTHD(256, 6, 1);
exec sp_ThemCTHD(257, 2, 2);
exec sp_ThemCTHD(258, 3, 1);
exec sp_ThemCTHD(259, 4, 2);
exec sp_ThemCTHD(260, 7, 3);
exec sp_ThemCTHD(261, 6, 1);
exec sp_ThemCTHD(261, 8, 1);
exec sp_ThemCTHD(262, 9, 4);
exec sp_ThemCTHD(263, 13, 1);
exec sp_ThemCTHD(263, 14, 1);
exec sp_ThemCTHD(263, 9, 2);
exec sp_ThemCTHD(263, 15, 5);
exec sp_ThemCTHD(264, 16, 4);
exec sp_ThemCTHD(265, 2, 2);
exec sp_ThemCTHD(266, 3, 1);
exec sp_ThemCTHD(267, 4, 2);
exec sp_ThemCTHD(268, 2, 1);
exec sp_ThemCTHD(269, 3, 1);
exec sp_ThemCTHD(270, 7, 3);
exec sp_ThemCTHD(271, 6, 1);
exec sp_ThemCTHD(272, 1, 1);
exec sp_ThemCTHD(273, 10, 1);
exec sp_ThemCTHD(274, 11, 2);
exec sp_ThemCTHD(275, 7, 1);
exec sp_ThemCTHD(276, 12, 2);
exec sp_ThemCTHD(277, 9, 1);
exec sp_ThemCTHD(278, 13, 1);
exec sp_ThemCTHD(279, 14, 1);
exec sp_ThemCTHD(280, 2, 1);
exec sp_ThemCTHD(280, 4, 3);
exec sp_ThemCTHD(280, 8, 1);
exec sp_ThemCTHD(281, 6, 1);
exec sp_ThemCTHD(282, 8, 1);
exec sp_ThemCTHD(283, 9, 4);
exec sp_ThemCTHD(284, 13, 1);
exec sp_ThemCTHD(285, 14, 1);
exec sp_ThemCTHD(286, 9, 2);
exec sp_ThemCTHD(286, 15, 5);
exec sp_ThemCTHD(287, 16, 4);
exec sp_ThemCTHD(288, 2, 2);
exec sp_ThemCTHD(289, 3, 1);
exec sp_ThemCTHD(290, 4, 2);
exec sp_ThemCTHD(291, 2, 1);
exec sp_ThemCTHD(291, 3, 1);
exec sp_ThemCTHD(292, 7, 3);
exec sp_ThemCTHD(292, 6, 1);
exec sp_ThemCTHD(293, 10, 1);
exec sp_ThemCTHD(294, 13, 3);
exec sp_ThemCTHD(295, 11, 2);
exec sp_ThemCTHD(296, 7, 1);
exec sp_ThemCTHD(296, 12, 2);
exec sp_ThemCTHD(297, 9, 1);
exec sp_ThemCTHD(298, 13, 1);
exec sp_ThemCTHD(299, 14, 1);
exec sp_ThemCTHD(300, 2, 1);
exec sp_ThemCTHD(301, 4, 3);
exec sp_ThemCTHD(302, 8, 1);
exec sp_ThemCTHD(303, 1, 1);
exec sp_ThemCTHD(304, 2, 1);
exec sp_ThemCTHD(304, 1, 1);
exec sp_ThemCTHD(305, 3, 1);
exec sp_ThemCTHD(306, 2, 1);
exec sp_ThemCTHD(307, 3, 1);
exec sp_ThemCTHD(308, 2, 1);
exec sp_ThemCTHD(309, 4, 1);
exec sp_ThemCTHD(310, 14, 1);
exec sp_ThemCTHD(311, 5, 1);
exec sp_ThemCTHD(312, 6, 1);
exec sp_ThemCTHD(313, 1, 1);
exec sp_ThemCTHD(314, 7, 1);
exec sp_ThemCTHD(315, 6, 1);
exec sp_ThemCTHD(316, 2, 2);
exec sp_ThemCTHD(317, 3, 1);
exec sp_ThemCTHD(318, 4, 2);
exec sp_ThemCTHD(319, 7, 3);
exec sp_ThemCTHD(320, 6, 1);
exec sp_ThemCTHD(321, 8, 1);
exec sp_ThemCTHD(322, 9, 1);
exec sp_ThemCTHD(323, 13, 1);
exec sp_ThemCTHD(324, 14, 1);
exec sp_ThemCTHD(325, 9, 2);
exec sp_ThemCTHD(326, 15, 1);
exec sp_ThemCTHD(327, 16, 2);
exec sp_ThemCTHD(328, 2, 2);
exec sp_ThemCTHD(329, 3, 1);
exec sp_ThemCTHD(330, 4, 2);
exec sp_ThemCTHD(331, 2, 1);
exec sp_ThemCTHD(332, 3, 1);
exec sp_ThemCTHD(333, 7, 3);
exec sp_ThemCTHD(334, 6, 1);
exec sp_ThemCTHD(334, 16, 1);
exec sp_ThemCTHD(335, 10, 4);
exec sp_ThemCTHD(336, 11, 2);
exec sp_ThemCTHD(337, 7, 1);
exec sp_ThemCTHD(338, 12, 1);
exec sp_ThemCTHD(339, 9, 1);
exec sp_ThemCTHD(340, 13, 5);
exec sp_ThemCTHD(341, 14, 3);
exec sp_ThemCTHD(342, 2, 1);
exec sp_ThemCTHD(343, 4, 1);
exec sp_ThemCTHD(344, 8, 1);
exec sp_ThemCTHD(345, 1, 1);
exec sp_ThemCTHD(346, 2, 2);
exec sp_ThemCTHD(347, 15, 1);
exec sp_ThemCTHD(348, 3, 3);
exec sp_ThemCTHD(349, 2, 1);
exec sp_ThemCTHD(350, 3, 2);
exec sp_ThemCTHD(351, 2, 1);
exec sp_ThemCTHD(352, 16, 4);
exec sp_ThemCTHD(353, 4, 1);
exec sp_ThemCTHD(354, 5, 2);
exec sp_ThemCTHD(355, 6, 1);
exec sp_ThemCTHD(356, 1, 1);
exec sp_ThemCTHD(357, 7, 3);
exec sp_ThemCTHD(358, 6, 1);
exec sp_ThemCTHD(359, 2, 2);
exec sp_ThemCTHD(360, 3, 1);
exec sp_ThemCTHD(361, 5, 1);
exec sp_ThemCTHD(362, 7, 3);
exec sp_ThemCTHD(363, 6, 1);
exec sp_ThemCTHD(363, 8, 1);
exec sp_ThemCTHD(363, 9, 4);
exec sp_ThemCTHD(364, 12, 1);
exec sp_ThemCTHD(365, 11, 1);
exec sp_ThemCTHD(365, 9, 2);
exec sp_ThemCTHD(366, 15, 1);
exec sp_ThemCTHD(366, 16, 2);
exec sp_ThemCTHD(367, 2, 1);
exec sp_ThemCTHD(367, 3, 1);

commit;

-- select *
--SELECT * FROM NHACUNGCAP;
--SELECT * FROM THELOAI;
--SELECT * FROM SACH;
--SELECT * FROM KHACHHANG;
--SELECT * FROM NHANVIEN;
--SELECT * FROM TAIKHOAN;
--SELECT * FROM HOADON;
--SELECT * FROM CTHD;
--SELECT * FROM PHIEUNHAP;
--SELECT * FROM CTPN;

-- FUNCTION
/
create or replace function insert_new_MaHD
return number
is
    v_MaHD_new HOADON.MAHD%type;
begin
    select MAX(MaHD) into v_MaHD_new
    from HOADON;
    
    return v_MaHD_new + 1;
end;
/
create or replace function insert_new_MaPN
return number
is
    v_MaPN_new PHIEUNHAP.MAPN%type;
begin
    select MAX(MaPN) into v_MaPN_new
    from PHIEUNHAP;
    
    return v_MaPN_new + 1;
end;
/
create or replace function insert_new_MaNV
return number
is
    v_MaNV_new NHANVIEN.MANV%type;
begin
    select MAX(MaNV) into v_MaNV_new
    from NHANVIEN;
    
    return v_MaNV_new + 1;
end;
/
create or replace function insert_new_MaKH
return number
is
    v_MaKH_new KHACHHANG.MAKH%type;
begin
    select MAX(MaKH) into v_MaKH_new
    from KHACHHANG;
    
    return v_MaKH_new + 1;
end;
/
create or replace function insert_new_MaSach
return number
is
    v_MaSach_new SACH.MASACH%type;
begin
    select MAX(MaSach) into v_MaSach_new
    from SACH;
    
    return v_MaSach_new + 1;
end;
/
create or replace function insert_new_MaTK
return number
is
    v_MaTK_new TAIKHOAN.MATK%type;
begin
    select MAX(MaTK) into v_MaTK_new
    from TAIKHOAN;
    
    return v_MaTK_new + 1;
end;
/
create or replace function insert_new_MaTL
return number
is
    v_MaTL_new THELOAI.MATL%type;
begin
    select MAX(MaTL) into v_MaTL_new
    from THELOAI;
    
    return v_MaTL_new + 1;
end;
/
create or replace function insert_new_MaNCC
return number
is
    v_MaNCC_new NHACUNGCAP.MANCC%type;
begin
    select MAX(MaNCC) into v_MaNCC_new
    from NHACUNGCAP;
    
    return v_MaNCC_new + 1;
end;
/

commit;

/
create or replace function fn_DoanhThuTheoThangNam(
    f_month_in number,
    f_year_in number
)
return number
is
    v_total number;
begin
    select sum(ThanhTien) into v_total
    from HOADON
    where extract(Month from NGAYHD) = f_month_in and extract(Year from NGAYHD) = f_Year_in;
    
    if (v_total is null) then
        v_total := 0;
    end if;
    
    return v_total;
end;
/
create or replace function fn_TinhLuongNhanVien
return number
is
    v_total number;
begin
    select sum(LUONG) into v_total
    from NHANVIEN;
       
    if (v_total is null) then
        v_total := 0;
    end if;
    
    return v_total;
end;
/
create or replace function fn_ChiPhiNhapSachTheoThangNam(
    f_month_in number,
    f_year_in number
)
return number
is
    v_total number;
begin
    select sum(TongTien) into v_total
    from PHIEUNHAP
    where extract(Month from NGAYNHAP) = f_month_in and extract(Year from NGAYNHAP) = f_Year_in;
    
    if (v_total is null) then
        v_total := 0;
    end if;
    
    return v_total;
end;
/
--select fn_ChiPhiNhapSachTheoThangNam(4, 2025) as ChiPhiNhap, fn_DoanhThuTheoThangNam(4, 2025) as DoanhThuThang, fn_TinhLuongNhanVien() as LuongNV from dual;
/
commit;

CREATE OR REPLACE PROCEDURE sp_ThemCTPN(
    v_MaPN_in IN CTPN.MaPN%type,
    v_MaSach_in IN CTPN.MaSach%type,
    v_SL_in IN CTPN.SL%type,
    v_Gia_in IN CTPN.GIA%type
)
AS
    v_sl NUMBER;
    v_TongTien NUMBER;
BEGIN
    -- Khóa dòng của bảng SACH trước khi thực hiện cập nhật
    SELECT SL INTO v_sl FROM SACH WHERE MaSach = v_MaSach_in FOR UPDATE;
    
    -- Khóa dòng của bảng PHIEUNHAP trước khi thực hiện cập nhật
    SELECT TongTien INTO v_TongTien FROM PHIEUNHAP WHERE MAPN = v_MaPN_in FOR UPDATE;
    
    INSERT INTO CTPN(MaPN, MaSach, SL, Gia) VALUES(v_MaPN_in, v_MaSach_in, v_SL_in, v_Gia_in);
    
    UPDATE PHIEUNHAP SET TongTien = v_TongTien + v_SL_in * v_Gia_in WHERE MAPN = v_MaPN_in;

    UPDATE SACH SET SL = v_sl + v_SL_in WHERE MaSach = v_MaSach_in;
    
    COMMIT;
END;
/
CREATE OR REPLACE PROCEDURE sp_ThemCTHD(
    v_MaHD_in IN CTHD.MaHD%type,
    v_MaSach_in IN CTHD.MaSach%type,
    v_SL_in IN CTHD.SL%type
)
AS
    v_MaKH KHACHHANG.MAKH%type;
    v_GiaSach SACH.GIA%type;
    v_valueCTHD number;
    v_DTL KHACHHANG.DIEMTICHLUY%type;
    v_sl NUMBER;
BEGIN
    -- Khóa dòng của bảng SACH trước khi thực hiện cập nhật
    SELECT SL INTO v_sl FROM SACH WHERE MaSach = v_MaSach_in FOR UPDATE;
    
    INSERT INTO CTHD(MaHD, MaSach, SL) VALUES(v_MaHD_in, v_MaSach_in, v_SL_in);
    
    UPDATE SACH SET SL = v_sl - v_SL_in WHERE MaSach = v_MaSach_in;
    
    -- Khóa dòng của bảng SACH để đảm bảo ràng không bị truy xuất hoặc cập nhật bởi các giao dịch khác
    SELECT Gia INTO v_GiaSach FROM SACH WHERE MaSach = v_MaSach_in FOR UPDATE;
    
    v_valueCTHD := v_SL_in * v_GiaSach;
    
    -- Khóa dòng của bảng HOADON trước khi thực hiện câu lệnh update
    UPDATE HOADON SET ThanhTien = ThanhTien + v_valueCTHD WHERE MAHD = v_MAHD_in;
    
    SELECT MAKH INTO v_MaKH FROM HOADON WHERE MAHD = v_MaHD_in;
    
    IF (v_MaKH IS NOT NULL) THEN
        UPDATE KHACHHANG SET DIEMTICHLUY = DIEMTICHLUY + v_valueCTHD WHERE MAKH = v_MaKH;
        
        SELECT DIEMTICHLUY INTO v_DTL FROM KHACHHANG WHERE MAKH = v_MaKH;
        
        IF (v_DTL >= 2000000) THEN
            UPDATE KHACHHANG SET LOAIKH = 'VIP' WHERE MAKH = v_MaKH;
        ELSIF (v_DTL >= 500000) THEN
            UPDATE KHACHHANG SET LOAIKH = 'Thân Thiết' WHERE MAKH = v_MaKH;
        ELSIF (v_DTL < 500000) THEN
            UPDATE KHACHHANG SET LOAIKH = 'Thường' WHERE MAKH = v_MaKH;
        END IF;
    END IF;
    sleep(10);
    COMMIT;
END;
/

--select SL from SACH where MASACH = 1;
--select * from HOADON;
--delete from CTHD where MaHD = 368;
--delete from CTPN where MAPN = 11;
--update sach set SL = 22 where MaSach = 1;
--select SL from SACH where Masach = 1;
--commit;

--SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
